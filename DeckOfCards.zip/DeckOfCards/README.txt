This application uses the angularJS framework of Javascript to shuffle, draw and sort cards in a deck of card to perform magic tricks.

1. It can shuffle the deck of cards
2. Draw any given number of cards from the deck by removing the cards from the deck and sort the drawn cards.