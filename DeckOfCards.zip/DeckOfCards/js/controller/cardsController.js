/* This is the controller registered with the module for this angularjs application.
Invoke this javascript file using script tag*/

app.controller('CardsCtrl', [
  '$scope',
  function ($scope) {
	  
	// Rank object is used to identify the sequence of the cards using their order numbers. 
    var rank;
	var rank_2;
	var rank_3;
	var rank_4;
	var rank_5;
	var rank_6;
	var rank_7;
	var rank_8;
	var rank_9;
	var rank_10;
	var rank_J;
	var rank_Q;
	var rank_K;
	var rank_A;
	
    $scope.ranks = [];
	
	// Each Rank has a label to display where the rank from 2 to 10 uses their numbers and 1,11,12,13 uses A, J, Q, K respectively
    $scope.ranks.push({ label: 'A', value: 1 });
    for (rank = 2; rank <= 10; rank += 1) {
      $scope.ranks.push({ label: rank, value: rank });
    }
    $scope.ranks.push({ label: 'J', value: 11 });
    $scope.ranks.push({ label: 'Q', value: 12 });
    $scope.ranks.push({ label: 'K', value: 13 });
	//Each rank objects are created using their labels and displayed in html using the below code
    $scope.rank = $scope.ranks[0];
	$scope.rank_2 = $scope.ranks[1];
	$scope.rank_3 = $scope.ranks[2];
	$scope.rank_4 = $scope.ranks[3];
	$scope.rank_5 = $scope.ranks[4];
	$scope.rank_6 = $scope.ranks[5];
	$scope.rank_7 = $scope.ranks[6];
	$scope.rank_8 = $scope.ranks[7];
	$scope.rank_9 = $scope.ranks[8];
	$scope.rank_10 = $scope.ranks[9];
	$scope.rank_J = $scope.ranks[10];
	$scope.rank_Q = $scope.ranks[11];
	$scope.rank_K = $scope.ranks[12];;
    
	// Suits objects are used to identify the cards with images
    $scope.suits = [
      { name: 'hearts', symbol: '\u2665' },
      { name: 'clubs', symbol: '\u2663' },
      { name: 'diamonds', symbol: '\u2666' },
      { name: 'spades', symbol: '\u2660' }
    ];
    $scope.suit = $scope.suits[0];
	$scope.suit_clubs = $scope.suits[1];
	$scope.suit_diamonds = $scope.suits[2];
	$scope.suit_spades = $scope.suits[3];
  }
]);