/*global angular */
 
 /* This is the main module registered for this angularjs application.
Invoke this javascript file using script tag.

@type {angular.Module)
*/

var app = angular.module('app', []);