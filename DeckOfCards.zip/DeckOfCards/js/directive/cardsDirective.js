/*
global angular 
*/

/*
Directive that executes an expression when the element it is applied to gets an event for the change of card.
This is the angularjs directive registered with the module for this angularjs application.
Invoke this javascript file using script tag
*/

app.directive('playingCard', [
  function () {
    return {
      replace: true,
      templateUrl: 'playing-card.html', //gets the template url to display
      scope: {
        rank: '=',
        suit: '='
      },
      link: function ($scope, el$, attr) {
        $scope.symbols = [];
        $scope.isCourt = false;
        $scope.updateSymbols = function () { //function to change the card based on the selection
          var rank, suit;
          rank = $scope.rank;
          suit = $scope.suit;
          $scope.symbols = [];
          if (rank.value > 10) {
            $scope.isCourt = true;
            $scope.symbols.push(suit.symbol);
          } else {
            while (rank && $scope.symbols.length < rank.value) {
              $scope.symbols.push(suit.symbol);
            }
          }
        };
		//Register a watch on the cards to check and identify which card among the pack is chosen and update the card
        $scope.$watch('rank', $scope.updateSymbols);
        $scope.$watch('suit', $scope.updateSymbols);
      }
    };
  }
]);